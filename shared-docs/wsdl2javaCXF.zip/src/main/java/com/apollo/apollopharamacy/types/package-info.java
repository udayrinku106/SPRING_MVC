@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.apollo.com/apollopharamacy/types", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.apollo.apollopharamacy.types;
