package com.aranin.weblog4j.vo;

import javax.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;

@XmlRootElement(name = "Book")
public class BookVO implements Serializable {

    private long bookId;
    private String bookName;
    private String author;

    
    public BookVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookVO(long bookId, String bookName, String author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
	}

	public long getBookId() {
        return bookId;
    }

    public void setBookId(long bucketId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

	@Override
	public String toString() {
		return "BookVO [bookId=" + bookId + ", bookName=" + bookName
				+ ", author=" + author + "]";
	}
    
    
}