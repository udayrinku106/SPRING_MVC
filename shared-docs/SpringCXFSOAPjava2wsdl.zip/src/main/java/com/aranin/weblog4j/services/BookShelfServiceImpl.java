package com.aranin.weblog4j.services;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.aranin.weblog4j.vo.BookVO;

@WebService( endpointInterface = "com.aranin.weblog4j.services.BookShelfService", serviceName = "bookShelfService")
public class BookShelfServiceImpl implements BookShelfService {
	
	
	public String insertBook(BookVO bookVO) {
		// HashDB.insertBook(bookVO);
		return "Book with name : " + bookVO.getBookName()
				+ " is now available on the shelf"; // To change body of
													// implemented methods use
													// File | Settings | File
													// Templates.
	}

	public BookVO getBook(long bookId) {

		return new BookVO(1234L, "BOOK1", "AUTHOR1"); // To change body of
														// implemented methods
														// use File | Settings |
														// File Templates.
	}

	public List<BookVO> getBookList() {
		// TODO Auto-generated method stub
		List<BookVO> bookList = null;

		bookList = new ArrayList<BookVO>();

		for (int i = 1; i <= 10; i++) {
			BookVO v1 = new BookVO(i, "BOOK" + i, "AUTHOR" + i);
			bookList.add(v1);
		}

		return bookList;
	}
}